package studentrecordsystem;

public class Student{

    private String studentId;
    private String name;
    private String department;
    private int semester;
    private double gpa;

    // Constructor to initialize student information
    public Student(String studentId, String name,
                   String department, int semester, double gpa) {
        this.studentId = studentId;
        this.name = name;
        this.department = department;
        this.semester = semester;
        this.gpa = gpa;
    }

    // Return student ID
    public String getStudentId() {
        return studentId;
    }

    // Return student name
    public String getName() {
        return name;
    }

    // Return department
    public String getDepartment() {
        return department;
    }

    // Return semester
    public int getSemester() {
        return semester;
    }

    // Return GPA
    public double getGpa() {
        return gpa;
    }

    // Update student information
    public void updateDetails(String name, String department,
                              int semester, double gpa) {
        this.name = name;
        this.department = department;
        this.semester = semester;
        this.gpa = gpa;
    }

    // Display student information
    public void display() {
        System.out.printf(
            "%-12s %-20s %-15s %-10d %.2f%n",
            studentId, name, department, semester, gpa
        );
    
}

	public Student copy() {
		// TODO Auto-generated method stub
		return null;
	}}
    