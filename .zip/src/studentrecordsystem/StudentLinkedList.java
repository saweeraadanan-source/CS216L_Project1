package studentrecordsystem;

public class StudentLinkedList {

    private class Node {
        Student data;
        Node next;

        Node(Student data) {
            this.data = data;
            this.next = null;
        }
    }

    private Node head;
    private int size;

    public StudentLinkedList() {
        head = null;
        size = 0;
    }

    // Check whether a student ID already exists.
    public boolean containsId(String id) {
        Node current = head;

        while (current != null) {
            if (current.data.getStudentId().equalsIgnoreCase(id)) {
                return true;
            }
            current = current.next;
        }

        return false;
    }

    // Add a student at the end of the list.
    public boolean addStudent(Student student) {
        if (containsId(student.getStudentId())) {
            return false;
        }

        Node newNode = new Node(student);

        if (head == null) {
            head = newNode;
        } else {
            Node current = head;

            while (current.next != null) {
                current = current.next;
            }

            current.next = newNode;
        }

        size++;
        return true;
    }

    // Display all students.
    public void displayAll() {
        if (head == null) {
            System.out.println("No student records found.");
            return;
        }

        System.out.printf("%-12s %-20s %-15s %-10s %s%n",
                "Student ID", "Name", "Department", "Semester", "GPA");
        System.out.println("----------------------------------------------------------------");

        Node current = head;

        while (current != null) {
            current.data.display();
            current = current.next;
        }
    }

    // Linear Search: find a student by ID.
    public Student searchStudent(String id) {
        Node current = head;

        while (current != null) {
            if (current.data.getStudentId().equalsIgnoreCase(id)) {
                return current.data;
            }
            current = current.next;
        }

        return null;
    }

    // Delete a student and return a copy for undo.
    public Student deleteStudent(String id) {
        Node current = head;
        Node previous = null;

        while (current != null) {
            if (current.data.getStudentId().equalsIgnoreCase(id)) {
                Student deletedStudent = current.data.copy();

                if (previous == null) {
                    head = current.next;
                } else {
                    previous.next = current.next;
                }

                // Disconnect the removed node.
                current.next = null;
                current = null;
                size--;

                return deletedStudent;
            }

            previous = current;
            current = current.next;
        }

        return null;
    }

    // Update student details.
    public boolean updateStudent(String id, String name,
                                 String department, int semester,
                                 double gpa) {
        Student student = searchStudent(id);

        if (student == null) {
            return false;
        }

        student.updateDetails(name, department, semester, gpa);
        return true;
    }

    // Restore a previously deleted student.
    public boolean restoreStudent(Student student) {
        return addStudent(student.copy());
    }

    // Return the total number of records.
    public int getSize() {
        return size;
    }

    // Bubble Sort: highest GPA first.
    public void sortByGPA() {
        if (head == null || head.next == null) {
            System.out.println("Not enough records to sort.");
            return;
        }

        boolean swapped;

        do {
            swapped = false;
            Node current = head;

            while (current.next != null) {
                if (current.data.getGpa() <
                        current.next.data.getGpa()) {

                    Student temp = current.data;
                    current.data = current.next.data;
                    current.next.data = temp;

                    swapped = true;
                }

                current = current.next;
            }
        } while (swapped);

        System.out.println("Students sorted by GPA (highest first).");
    }
}
