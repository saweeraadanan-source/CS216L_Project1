package studentrecordsystem;

public class UndoStack {

    private class StackNode {
        UndoAction action;
        StackNode next;

        StackNode(UndoAction action) {
            this.action = action;
            this.next = null;
        }
    }

    private StackNode top;

    public UndoStack() {
        top = null;
    }

    // Add an action to the top of the stack.
    public void push(UndoAction action) {
        StackNode newNode = new StackNode(action);
        newNode.next = top;
        top = newNode;
    }

    // Remove and return the top action.
    public UndoAction pop() {
        if (isEmpty()) {
            return null;
        }

        UndoAction action = top.action;
        StackNode temp = top;
        top = top.next;
        temp.next = null;
        return action;
    }

    // View the top action without removing it.
    public UndoAction peek() {
        if (isEmpty()) {
            return null;
        }
        return top.action;
    }

    public boolean isEmpty() {
        return top == null;
    }

    // Display actions from newest to oldest.
    public void display() {
        if (isEmpty()) {
            System.out.println("Undo history is empty.");
            return;
        }

        StackNode current = top;
        int number = 1;

        System.out.println("\n--- Undo History ---");

        while (current != null) {
            Student student = current.action.getPreviousStudent();

            System.out.println(number + ". " +
                    current.action.getActionType() +
                    " | Student ID: " + student.getStudentId());

            current = current.next;
            number++;
        }
    }
}
