package studentrecordsystem;

public class UndoAction {
    private String actionType;
    private Student previousStudent;

    public UndoAction(String actionType, Student previousStudent) {
        this.actionType = actionType;
        this.previousStudent = previousStudent.copy();
    }

    public String getActionType() {
        return actionType;
    }

    public Student getPreviousStudent() {
        return previousStudent.copy();
    }
}