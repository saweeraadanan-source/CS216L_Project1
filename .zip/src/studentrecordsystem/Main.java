package studentrecordsystem;

import java.util.Scanner;

public class Main {

    private static final Scanner input = new Scanner(System.in);

    private static final StudentLinkedList students =
            new StudentLinkedList();

    private static final UndoStack undoStack = new UndoStack();

    public static void main(String[] args) {

        int choice;

        do {
            System.out.println("\n===== STUDENT RECORD SYSTEM =====");
            System.out.println("1. Add Student");
            System.out.println("2. Display All Students");
            System.out.println("3. Search Student by ID");
            System.out.println("4. Delete Student");
            System.out.println("5. Update Student");
            System.out.println("6. Sort Students by GPA");
            System.out.println("7. Undo Last Delete/Update");
            System.out.println("8. View Undo History");
            System.out.println("9. Count Students");
            System.out.println("0. Exit");

            choice = readInt("Enter your choice: ", 0, 9);

            switch (choice) {
                case 1:
                    addStudent();
                    break;

                case 2:
                    students.displayAll();
                    break;

                case 3:
                    searchStudent();
                    break;

                case 4:
                    deleteStudent();
                    break;

                case 5:
                    updateStudent();
                    break;

                case 6:
                    students.sortByGPA();
                    students.displayAll();
                    break;

                case 7:
                    undoLastAction();
                    break;

                case 8:
                    undoStack.display();
                    break;

                case 9:
                    System.out.println("Total students: "
                            + students.getSize());
                    break;

                case 0:
                    System.out.println("Program closed. Goodbye!");
                    break;
            }

        } while (choice != 0);

        input.close();
    }

    // Add a new student after validating the information.
    private static void addStudent() {

        String id = readText("Enter student ID: ");

        if (students.containsId(id)) {
            System.out.println("Error: This student ID already exists.");
            return;
        }

        String name = readText("Enter student name: ");
        String department = readText("Enter department: ");
        int semester = readInt("Enter semester (1-8): ", 1, 8);
        double gpa = readDouble("Enter GPA (0.0-4.0): ", 0.0, 4.0);

        Student student =
                new Student(id, name, department, semester, gpa);

        if (students.addStudent(student)) {
            System.out.println("Student added successfully.");
        } else {
            System.out.println("Could not add student.");
        }
    }

    // Search using Linear Search.
    private static void searchStudent() {

        String id = readText("Enter student ID to search: ");
        Student student = students.searchStudent(id);

        if (student == null) {
            System.out.println("Student not found.");
        } else {
            System.out.println("Student found:");
            System.out.printf("%-12s %-20s %-15s %-10s %s%n",
                    "Student ID", "Name", "Department",
                    "Semester", "GPA");
            student.display();
        }
    }

    // Delete a student and save the action on the stack.
    private static void deleteStudent() {

        String id = readText("Enter student ID to delete: ");

        Student deleted = students.deleteStudent(id);

        if (deleted == null) {
            System.out.println("Student not found.");
        } else {
            undoStack.push(new UndoAction("DELETE", deleted));
            System.out.println("Student deleted successfully.");
        }
    }

    // Save the old information before updating.
    private static void updateStudent() {

        String id = readText("Enter student ID to update: ");
        Student existing = students.searchStudent(id);

        if (existing == null) {
            System.out.println("Student not found.");
            return;
        }

        // Store the old details before making changes.
        Student oldStudent = existing.copy();

        String name = readText("Enter new name: ");
        String department = readText("Enter new department: ");
        int semester = readInt("Enter new semester (1-8): ", 1, 8);
        double gpa = readDouble("Enter new GPA (0.0-4.0): ", 0.0, 4.0);

        if (students.updateStudent(id, name, department, semester, gpa)) {
            undoStack.push(new UndoAction("UPDATE", oldStudent));
            System.out.println("Student updated successfully.");
        } else {
            System.out.println("Update failed.");
        }
    }

    // Undo the most recent delete or update.
    private static void undoLastAction() {

        if (undoStack.isEmpty()) {
            System.out.println("Nothing to undo.");
            return;
        }

        UndoAction action = undoStack.pop();
        Student previous = action.getPreviousStudent();

        if (action.getActionType().equals("DELETE")) {

            if (students.restoreStudent(previous)) {
                System.out.println("Deleted student restored successfully.");
            } else {
                // Keep the action available if restoration cannot occur.
                undoStack.push(action);
                System.out.println(
                        "Undo failed: a student with this ID already exists.");
            }

        } else if (action.getActionType().equals("UPDATE")) {

            Student current =
                    students.searchStudent(previous.getStudentId());

            if (current != null) {
                students.updateStudent(
                        previous.getStudentId(),
                        previous.getName(),
                        previous.getDepartment(),
                        previous.getSemester(),
                        previous.getGpa()
                );

                System.out.println("Previous student details restored.");
            } else {
                undoStack.push(action);
                System.out.println(
                        "Undo failed: student record was not found.");
            }
        }
    }

    // Read a non-empty string.
    private static String readText(String message) {

        while (true) {
            System.out.print(message);
            String value = input.nextLine().trim();

            if (!value.isEmpty()) {
                return value;
            }

            System.out.println("Input cannot be empty. Try again.");
        }
    }

    // Read an integer within the given range.
    private static int readInt(String message, int min, int max) {

        while (true) {
            System.out.print(message);
            String value = input.nextLine().trim();

            try {
                int number = Integer.parseInt(value);

                if (number >= min && number <= max) {
                    return number;
                }

                System.out.println("Enter a number from "
                        + min + " to " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Enter a whole number.");
            }
        }
    }

    // Read a decimal number within the given range.
    private static double readDouble(String message,
                                     double min, double max) {

        while (true) {
            System.out.print(message);
            String value = input.nextLine().trim();

            try {
                double number = Double.parseDouble(value);

                if (Double.isFinite(number)
                        && number >= min && number <= max) {
                    return number;
                }

                System.out.println("Enter a number from "
                        + min + " to " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Enter a valid number.");
            }
        }
    }
}
